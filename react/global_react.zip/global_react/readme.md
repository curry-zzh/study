- 国际化前端项目, 
  1. 流行的  react + ts + i18n
    全球都用, hello   你好   안녕하세요
  2. react + ts   工作流搭建过程 
    - tsconfig.json  ts 配置文件 